---------------------------------------------------------------
-- Airline Database: list the tables
-- created by M. Liu,  Fall 2011
---------------------------------------------------------------
select count(*)  from flight;
select count(*) from aircraft; 
select count(*) from employee;
select count(*) from certified;
