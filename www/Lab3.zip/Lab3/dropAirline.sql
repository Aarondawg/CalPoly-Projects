--  This file drops the tables for the
--  airline database.
--  M. Liu, Fall 2011
drop table flight;
drop table certified;
drop table aircraft cascade constraints;
drop table employee cascade constraints;
