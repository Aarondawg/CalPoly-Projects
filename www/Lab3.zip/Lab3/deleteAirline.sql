-- script for clearing existing data 
-- from the tables in the airlines database
DELETE FROM flight;
DELETE FROM certified;
DELETE FROM employee;
DELETE FROM aircraft;
