---------------------------------------------------------------
-- Airline Database: Insert tuples to the EMPLOYEE table
-- created by M. Liu,  Fall 2011
---------------------------------------------------------------
insert into employee values(242518965,'James Wong',1204330,null);
insert into employee values(141582651,'Mary Johnson',178345,242518965);
insert into employee values(011564812,'John Williams',153972,242518965);
insert into employee values(567354612,'Lisa Walker',256481,242518965);
insert into employee values(552455318,'Larry Nguyen',101745,141582651);
insert into employee values(550156548,'Karen Scott',205187,141582651);
insert into employee values(390487451,'Lawrence Sperry',212156,141582651);
insert into employee values(274878974,'Michael Miller',99890,011564812);
insert into employee values(254099823,'Patricia Jones',24450,011564812);
insert into employee values(356187925,'Robert Brown',44740,011564812);
insert into employee values(355548984,'Angela Martinez',212156,567354612); 
insert into employee values(310454876,'Joseph Thompson',212156,567354612);
insert into employee values(489456522,'Linda Shingh',127984,552455318);
insert into employee values(489221823,'Richard Jackson',23980,552455318);
insert into employee values(548977562,'William Ward',84476,552455318);
insert into employee values(310454877,'Chad Stewart',33546,552455318);
insert into employee values(142519864,'Betty Adams',227489,552455318);
insert into employee values(269734834,'George Wright',289950,550156548);
insert into employee values(287321212,'Michael Miller',48090,550156548);
insert into employee values(552455348,'Dorthy Lewis',92013,550156548);
insert into employee values(248965255,'Miles Wilson',43723,274878974);
insert into employee values(159542516,'William Moore',48250,274878974);
insert into employee values(348121549,'Haywood Kelly',32899,248965255);
insert into employee values(090873519,'Liz Chang',32021,159542516);
insert into employee values(486512566,'David Anderson',743001,356187925);
insert into employee values(619023588,'Jennifer Thomas',54921,356187925);
insert into employee values(015645489,'Donald King',18050,619023588);
insert into employee values(556784565,'Mark Young',205187,015645489);
insert into employee values(573284895,'Eric Cooper',114323,619023588);
insert into employee values(574489456,'William Jones',105743,573284895);
insert into employee values(574489457,'Milo Brooks',20,573284895);
