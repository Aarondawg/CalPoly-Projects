---------------------------------------------------------------
-- Airline Database: Insert tuples to the AIRCRAFT table
-- created by M. Liu,  Fall 2011
---------------------------------------------------------------
insert into aircraft values(1,'Boeing 747-400',8430);
insert into aircraft values(2,'Boeing 737-800',3383);
insert into aircraft values(3,'Airbus A340-300',7120);
insert into aircraft values(4,'British Jetstream 41',1502);
insert into aircraft values(5,'Embraer ERJ-145',1530);
insert into aircraft values(6,'SAAB 340',2128);
insert into aircraft values(7,'Piper Archer III',520);
insert into aircraft values(8,'Tupolev 154',4103);
insert into aircraft values(16,'Schwitzer 2-33',30);
insert into aircraft values(9,'Lockheed L1011',6900);
insert into aircraft values(10,'Boeing 757-300',4010);
insert into aircraft values(11,'Boeing 777-300',6441);
insert into aircraft values(12,'Boeing 767-400ER',6475);
insert into aircraft values(13,'Airbus A320',2605);
insert into aircraft values(14,'Airbus A319',1805);
insert into aircraft values(15,'Boeing 727',1504);
