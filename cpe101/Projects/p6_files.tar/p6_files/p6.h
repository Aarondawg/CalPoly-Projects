#define SEND 1
#define LIST 2
#define DELETE 3

#define STR_LEN 81
#define MSG_LEN 251

#define USER_NOT_FOUND_MSG "User Not Found"
#define INVALID_INDEX_MSG "Invalid Message Index to Delete"
#define TOO_MANY_MESSAGES_MSG "Too Many Messages For User"
